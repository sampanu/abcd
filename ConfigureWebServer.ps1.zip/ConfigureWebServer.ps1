Configuration Main
{
  param (
  $MachineName,
  $WebDeployPackagePath,
  $UserName,
  $Password
  )

  Node ($MachineName)
  {
	Script DeployWebPackage
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		<#
			$WebClient = New-Object -TypeName System.Net.WebClient
			$Destination= "C:\WindowsAzure\WebApplication.zip" 
			$WebClient.DownloadFile($using:WebDeployPackagePath,$destination)
			$ConnectionStringName = "DefaultConnection-Web.config Connection String"
			$ConnectionString = "Server=tcp:"+ "$using:DbServerName" + ".database.windows.net,1433;Database=" + "$using:DbName" + ";User ID=" + "$using:DbUserName" + "@$using:DbServerName" + ";Password=" + "$using:DbPassword"+ ";Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;"
			$ConnectionString | Out-File -filepath C:\WindowsAzure\outfile.txt -append -width 200
			$Argument = '-source:package="C:\WindowsAzure\WebApplication.zip"' + ' -dest:auto,ComputerName="localhost",'+"username=$using:UserName" +",password=$using:Password" + ' -setParam:name="' + "$ConnectionStringName" + '"'+',value="' + "$ConnectionString" + '" -verb:sync -allowUntrusted'
			$MSDeployPath = (Get-ChildItem "HKLM:\SOFTWARE\Microsoft\IIS Extensions\MSDeploy" | Select -Last 1).GetValue("InstallPath")
			Start-Process "$MSDeployPath\msdeploy.exe" $Argument -Verb runas
		#>
		
		md c:\test02
        
        }

	}
  }
}
